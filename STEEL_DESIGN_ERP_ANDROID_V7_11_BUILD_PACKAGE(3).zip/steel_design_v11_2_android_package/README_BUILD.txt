STEEL DESIGN ERP V11.2 — Android build package

IMPORTANT: www/index.html is the original uploaded V11.2 HTML file copied byte-for-byte.
No HTML, CSS, JavaScript, labels, layout, branding, or business logic was modified.

Build with the repository's existing GitHub Actions workflow:
1. Replace the old STEEL_DESIGN_ERP_ANDROID_V7_11_BUILD_PACKAGE.zip in the repository root with this ZIP, keeping that exact filename.
2. Commit the replacement to the main branch.
3. The existing .github/workflows/android-apk.yml workflow starts on push.
4. Download the generated APK from the workflow run's Artifacts section.
